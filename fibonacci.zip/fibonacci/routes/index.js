router.get('/', function (req, res, next) {
  res.render('index', {
    title: "Welcome to the Fibonacci Calculator"
  });
});